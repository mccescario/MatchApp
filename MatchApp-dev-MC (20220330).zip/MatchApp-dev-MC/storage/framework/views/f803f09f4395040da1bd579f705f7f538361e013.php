<?php $__env->startSection('content'); ?>
    <div>
        <h1 style="padding: 20px 0px;">Edit Tournament Details</h1>
    </div>

    <div>
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-bg mb-3"> Back</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="container">
        <form method="POST" action="<?php echo e(route('tournament.update' , $tournament->id)); ?>"  x-data="{bracket: <?php echo e($tournament->tournament_bracket); ?>, sports: <?php echo e($tournament->tournament_sport_type); ?>, sport: <?php echo e($tournament->tournament_sport); ?>, esport: <?php echo e($tournament->tournament_esport); ?> , fee: 2, single_round: <?php echo e($tournament->single_best_of_rounds); ?> }" >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="d-lg-flex justify-content-lg-center align-items-lg-center" style="text-align: center;">
                <div>
                    <label class="form-label" style="margin: 3px;padding: 4px;">Tournament Name:&nbsp;</label>
                    <input type="text" name="tournament_name" placeholder="<?php echo e($tournament->tournament_name); ?>">
                </div>
                <div>
                    <label class="form-label" style="margin: 3px;padding: 4px;">Start Date:&nbsp;</label>
                    <input placeholder="<?php echo e($tournament->tournament_date); ?>" type="text" onfocus="(this.type='date')" onblur="(this.type='text')" name="tournament_date" >
                </div>
            </div>
            <div>
                <div class="d-xl-flex justify-content-xl-center align-items-xl-center" style="margin: 10px;">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'sports','class' => 'form-label','style' => 'margin: 3px;padding: 4px;','value' => ' '.e(__('Sports / E-Sports: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'sports','class' => 'form-label','style' => 'margin: 3px;padding: 4px;','value' => ' '.e(__('Sports / E-Sports: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <select name=tournament_sport_type x-model="sports" style="padding: 1px 2px;">
                            <option value="1">Sports</option>
                            <option value="2">E-Sports</option>
                    </select>
                </div>
            </div>

            <div class="d-xl-flex justify-content-xl-center align-items-xl-center" style="margin: -8px;">

                <div style="margin: 13px;" x-show="sports == 1">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Select Sport Game:')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Select Sport Game:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <select style="padding: 1px 2px;" name="tournament_sport">
                        <option value="1">Basketball</option>
                        <option value="2">Volleyball</option>
                    </select>
                </div>

                <div style="margin: 13px;" x-show="sports == 2">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Select E-Sport Game:')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Select E-Sport Game:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <select style="padding: 1px 2px;" x-model="esport" name="tournament_esport">
                        <option value="1">League of Legends (LoL)</option>
                        <option value="2">Defence of the Ancients 2 (DOTA2)</option>
                    </select>
                </div>

                <div style="margin: 13px;">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'bracket','class' => 'form-label','value' => ''.e(__('Bracket Type: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'bracket','class' => 'form-label','value' => ''.e(__('Bracket Type: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <select name="tournament_bracket" x-model="bracket" style="padding: 1px 2px;">

                        <option value="1">Single - Elimination</option>
                        <option value="2">Double - Elimination</option>
                        <option value="3">Round - Robin Elimination</option>
                    </select>
                </div>
            </div>

            <div class="d-xl-flex justify-content-xl-center align-items-xl-center" style="margin: -8px;">
                <div x-show="bracket == 1" >
                    <div class="d-flex justify-content-center align-self-centermy-1">

                        <label for="">&nbsp;Enable Third Place Match </label>
                        <select name="enable_third_place" id="">
                            <option value="1">Disabled</option>
                            <option value="2">Enabled</option>
                        </select>

                    </div>

                    <div class="my-1">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Bracket Size (# of teams/ players): ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Bracket Size (# of teams/ players): ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <input type="number" name="single_bracket_size" id="" placeholder="<?php echo e($tournament->single_bracket_size); ?>">
                    </div>

                    <div class="my-1">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Best of for all rounds: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Best of for all rounds: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <select name="single_best_of_rounds" style="padding: 1px 2px;" x-model="single_round">
                            <option value="1">1</option>
                            <option value="2">3</option>
                            <option value="3">5</option>
                            <option value="4">7</option>
                            <option value="5">9</option>
                            <option value="6">11</option>
                        </select>
                    </div>

                </div>

                <div x-show="bracket == 2" style="margin: 13px;">
                    <div>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Bracket Size (# of teams/ players): ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Bracket Size (# of teams/ players): ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <input type="number" name="double_bracket_size" id="" placeholder="<?php echo e($tournament->double_bracket_size); ?>">
                    </div>

                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Best of for all rounds: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Best of for all rounds: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <select name="double_best_of_rounds" style="padding: 1px 2px;">
                            <option value="1" selected>1</option>
                            <option value="2">3</option>
                            <option value="3">5</option>
                            <option value="4">7</option>
                            <option value="5">9</option>
                            <option value="6">11</option>
                        </select>
                    </div>
                </div>

                <div x-show="bracket == 3">
                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Number of groups: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Number of groups: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <input style="width:100px; padding: 1px 2px;" type="number" name="num_groups" id="">
                    </div>

                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Number of players per groups: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Number of players per groups: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <input style="width:100px; padding: 1px 2px;" type="number" name="num_player_per_group" id="">
                    </div>

                    <div class="mt-2">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'form-label','value' => ''.e(__('Match style: ')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-label','value' => ''.e(__('Match style: ')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <select name="round_robin_match_style" style="padding: 1px 2px; width:235px;">
                            <option value="1">Best of</option>
                            <option value="2">Games per match</option>
                        </select>
                        <input style="padding: 1px 2px; width:50px;" type="number" name="games_per_match" id="">
                    </div>


                </div>
            </div>

            <div>
                <div class="d-xl-flex justify-content-xl-center align-items-xl-center" style="margin: -8px;">
                    <div style="margin: 13px;">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'fee','class' => 'form-label','value' => ''.e(__('with Entry Fee:')).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'fee','class' => 'form-label','value' => ''.e(__('with Entry Fee:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        <select name="tournament_fee" x-model="fee" style="padding: 1px 2px;">
                            <option value="1">Yes</option>
                            <option value="2">None</option>
                        </select>
                    </div>

                    <div style="margin: 13px;" x-show="fee == 1">
                        <label class="form-label">Price: </label>
                        <input type="text" name="tournament_price">
                    </div>

                </div>
            </div>
            <div class="text-center" style="padding: 0px;margin: 0px;margin-top: 10px;">
                <button class="btn btn-primary" type="submit" style="padding: 9px 12px;background: var(--bs-yellow);color: rgb(26,69,11);">Save Changes</button>
            </div>

        </form>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.host.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/host/tournament/tournament_edit.blade.php ENDPATH**/ ?>