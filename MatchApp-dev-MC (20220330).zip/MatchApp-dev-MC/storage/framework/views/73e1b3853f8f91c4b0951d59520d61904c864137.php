

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <h3 class="text-dark mb-4">Tournaments</h3>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <td>You are joining to this tournament: <strong><?php echo e($tournament->tournament_name); ?></strong></td>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <div>
        <form action="<?php echo e(route('tournament.join', $tournament->id)); ?>" method="POST">

            <?php echo csrf_field(); ?>
            <input name="tournament_model_id" type="hidden" value="<?php echo e($tournament->id); ?>">
            <input name="status" type="hidden" value="JOINING">
            <strong>Your Team:</strong>
            <select name="team_id" class="form-control" required>
                <option value="">-- Select Team --</option>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($team->id); ?>"><?php echo e($team->team_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <br>
            <button class="btn btn-primary" type="submit">Join</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.normal.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/normal/tournament/tournament_join.blade.php ENDPATH**/ ?>