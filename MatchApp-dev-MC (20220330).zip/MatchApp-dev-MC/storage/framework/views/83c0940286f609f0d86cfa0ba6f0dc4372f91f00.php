<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <h3 class="text-dark mb-4"><?php echo e($tournament->tournament_name); ?></h3><button class="btn btn-primary btn-sm" type="submit" style="margin-top: 18px;margin-left: 0px;"><i class="fas fa-code-branch" style="width: 20px;"></i>&nbsp;Generate Bracket</button>
    <div class="row mb-3">
        <div class="col-lg-8" style="width: 897.6600000000002px;">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-3" style="width: 875.px;">
                        <div class="card-header py-3" style="height: 48px;">
                            <p class="text-primary fw-bold" style="height: 24px;margin-top: -4px;width: 904.6600000000002px;">Tournament Details</p>
                        </div>
                        <div class="card-body" style="width: 850.6600000000002px;">
                            <form method="POST" action="<?php echo e(route('tournament.update' , $tournament->id)); ?>" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="tournament_name"><strong>Tournament Name</strong></label>
                                            <input class="form-control" type="text" id="tournament_name" name="tournament_name" placeholder="<?php echo e($tournament->tournament_name); ?>" name="username"></div>
                                    </div>
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="tournament_size"><strong>Tournament Size - <?php if($tournament->tournament_size == 1): ?>2 <?php elseif($tournament->tournament_size == 2): ?>4  <?php elseif($tournament->tournament_size == 3): ?> 8 <?php elseif($tournament->tournament_size == 4): ?>16 <?php elseif($tournament->tournament_size == 5): ?>32 <?php elseif($tournament->tournament_size == 6): ?><?php elseif($tournament->tournament_size == 7): ?>128 <?php endif; ?></strong><br></label>
                                            <select class="form-select" name="tournament_size" id="tournament_size" placeholder="">
                                                <option value="0" selected>Change Tournament size</option>
                                                    <option value="1">2</option>
                                                    <option value="2">4</option>
                                                    <option value="3">8</option>
                                                    <option value="4">16</option>
                                                    <option value="5">32</option>
                                                    <option value="6">64</option>
                                                    <option value="7">128</option>
                                                </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="tournament_format"><strong>Tournament Format - <?php if($tournament->tournament_format == 1): ?> Single - Elimination <?php elseif($tournament->tournament_format == 2): ?>Double - Elimination <?php elseif($tournament->tournament_format == 3): ?>Round - Robin Elimination <?php endif; ?></strong></label>
                                            <select class="form-select" type="text" id="tournament_format" name="tournament_format" placeholder="">
                                                <option value="0" selected>Change Tournament Format</option>
                                                <option value="1">Single-Elimination</option>
                                                <option value="2">Double-Elimination</option>
                                                <option value="3">Round Robin</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label" for="last_name"><strong>Date of Tournament - <?php echo e($tournament->tournament_date_from); ?> - <?php echo e($tournament->tournament_date_to); ?> </strong></label>
                                            <input class="form-control" type="text" id="last_name-3" name="last_name" placeholder=""></div>
                                    </div>
                                    <div class="col">
                                        <div class="mb-3">
                                            <label class="form-label" for="tournament_sport"><strong>Game - <?php if($tournament->tournament_sport_type == 1): ?> <?php if($tournament->tournament_sport == 1): ?>Basketball <?php elseif($tournament->tournament_sport == 2): ?>Volleyaball <?php elseif($tournament->tournament_sport == 3): ?>Football <?php endif; ?> <?php elseif($tournament->tournament_sport_type == 2): ?> <?php if($tournament->tournament_esport == 1): ?> Valorant <?php elseif($tournament->tournament_esport == 2): ?>Mobile Legends <?php elseif($tournament->tournament_esport == 3): ?>Dota 2 <?php elseif($tournament->tournament_esport == 4): ?>Counter Strike: Global Offensive <?php elseif($tournament->tournament_esport == 5): ?>League of Legends <?php elseif($tournament->tournament_esport == 6): ?>Call of Duty: Mobile <?php endif; ?> <?php endif; ?></strong></label>
                                            <?php if($tournament->tournament_sport_type == 1): ?>
                                            <select class="form-control" type="text" id="tournament_sport" name="tournament_sport" placeholder="">
                                                <option value="0" selected>Change the Game</option>
                                                <option value="1">Basketball</option>
                                                <option value="2">Volleyball</option>
                                                <option value="3">Football</option>
                                            </select>
                                            <?php elseif($tournament->tournament_sport_type == 2): ?>
                                            <select class="form-select" id="tournament_esport" name="tournament_esport">
                                                <option value="0" selected>Change the Video Game</option>
                                                <option value="1">Valorant</option>
                                                <option value="2">Mobile Legends</option>
                                                <option value="3">Dota 2</option>
                                                <option value="4">Counter Strike: Global Offensive</option>
                                                <option value="5">League of Legends</option>
                                                <option value="6">Call of Duty: Mobile</option>
                                            </select>
                                            <?php endif; ?>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label" for="last_name"><strong>Series - <?php if($tournament->tournament_format == 1): ?> <?php if($tournament->tournament_series == 1): ?>Knockouts <?php elseif($tournament->tournament_series == 2): ?>Best of 3 <?php elseif($tournament->tournament_series == 3): ?>Best of 5 <?php elseif($tournament->tournament_series == 4): ?>Best of 7 <?php endif; ?> <?php elseif($tournament->tournament_format == 2): ?> <?php if($tournament->tournament_series == 1): ?>Knockouts <?php elseif($tournament->tournament_series == 2): ?>Best of 3 <?php elseif($tournament->tournament_series == 3): ?>Best of 5 <?php elseif($tournament->tournament_series == 4): ?>Best of 7 <?php endif; ?> <?php elseif($tournament->tournament_format == 3): ?> <?php if($tournament->tournament_participant_play == 1): ?>Once <?php elseif($tournament->tournament_participant_play == 2): ?>Twice <?php elseif($tournament->tournament_participant_play == 3): ?>Thrice <?php endif; ?> <?php endif; ?></strong></label>
                                            <?php if($tournament->tournament_format == 1): ?>
                                            <select class="form-select" id="tournament_series" name="tournament_series">
                                                <option value="0" selected>Change Series</option>
                                                <option value="1">Knockouts</option>
                                                <option value="2">Best of 3</option>
                                                <option value="3">Best of 5</option>
                                                <option value="4">Best of 7</option>
                                            </select>
                                            <?php elseif($tournament->tournament_format == 2): ?>
                                            <select class="form-select" id="tournament_series" name="tournament_series">
                                                <option value="0" selected>Change Series</option>
                                                <option value="1">Knockouts</option>
                                                <option value="2">Best of 3</option>
                                                <option value="3">Best of 5</option>
                                                <option value="4">Best of 7</option>
                                            </select>
                                            <?php elseif($tournament->tournament_format == 3): ?>
                                            <select class="form-select" id="tournament_participant_play" name="tournament_participant_play">
                                                <option value="0" selected>Change Series</option>
                                                <option value="1">Once</option>
                                                <option value="2">Twice</option>
                                                <option value="3">Thrice</option>
                                            </select>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3" style="margin-left: 0px;height: 25px;">
                                    <button class="btn btn-primary btn-sm" type="submit">
                                        <i class="fas fa-edit" style="width: 20px;"></i>Update
                                    </button>
                                </form>

                                    <button class="btn btn-primary btn-sm" type="submit">
                                        <i class="fas fa-search" style="width: 20px;"></i>View Registrants
                                    </button>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card shadow">
                <div class="card-header py-3" style="height: 48px;">
                    <p class="text-primary fw-bold" style="margin-top: -4px;">List of Participants</p>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="col">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th style="width: 275px;">Team Name</th>
                                                <!-- <th style="text-align: center;">Members</th> -->
                                                <th style="text-align: left;width: 75px;">Course</th>
                                                <th style="width: 250px;">Representative</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="text-align: left;"><?php echo e($participant->team->team_name); ?></td>
                                                <!-- <td style="width: 110px;text-align: center;">5</td> -->
                                                <td></td>
                                                <td></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="mb-3" style="height: 25px;"><button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-edit" style="width: 20px;"></i>Update</button></div> -->
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-3">
        <h3 class="text-dark mb-4">Joining Teams</h3>
        <div class="col">
            <div class="card shadow">
                <div class="card-header py-3" style="height: 48px;">
                    <p class="text-primary fw-bold" style="margin-top: -4px;">List of Teams</p>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="col">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th style="width: 275px;">Status</th>
                                                <th style="width: 275px;">Team Name</th>
                                                <th style="text-align: left;width: 75px;">Course</th>
                                                <th style="width: 250px;">Representative</th>
                                                <th style="width: 250px;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $joining_participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joining_participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="text-align: left;"><span class="btn btn-sm btn-primary"><?php echo e($joining_participant->status); ?></span></td>
                                                <td style="text-align: left;"><?php echo e($joining_participant->team->team_name); ?></td>
                                                <td></td>
                                                <td></td>
                                                <td>
                                                    <a href="<?php echo e(route('accept.tournament', $joining_participant->id)); ?>">
                                                        <span class="btn btn-sm btn-success">ACCEPT</span>
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="mb-3" style="height: 25px;"><button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-edit" style="width: 20px;"></i>Update</button></div> -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--
    <div class="card-header p-3">
        <h3 >View Tournament Details</h3>
    </div>



    <div class="container p-3">
        <div class="card shadow">
            <h5 class="card-header">Overview</h5>
            <div class="card-body p-5">
                <div class="row">

                    /
</div>-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.host.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/host/tournament/tournament_view.blade.php ENDPATH**/ ?>