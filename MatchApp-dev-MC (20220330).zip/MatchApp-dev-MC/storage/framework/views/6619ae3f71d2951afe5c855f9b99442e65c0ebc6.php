<?php
echo $results;
?><?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/host/tournament/result_json.blade.php ENDPATH**/ ?>