<footer class="bg-white sticky-footer">
    <div class="container my-auto">
        <div class="text-center my-auto copyright"><span>Copyright © MatchApp 2022</span></div>
    </div>
</footer>
<?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/normal/include/footer.blade.php ENDPATH**/ ?>