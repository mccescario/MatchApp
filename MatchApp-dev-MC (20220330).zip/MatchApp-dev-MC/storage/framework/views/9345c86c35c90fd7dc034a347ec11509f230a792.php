<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row mb-3">
        <div class="col">
            <div class="card shadow">
                <div class="card-header py-3" style="height: 64px;">
                    <p class="text-primary m-0 fw-bold" style="width: 978px;">Team Members</p>
                </div>
                <div class="card-body" style="margin-top: -15px;"><br>
                    
                    <div class="table-responsive table mt-2" id="dataTable-2" role="grid" aria-describedby="dataTable_info">
                        <table class="table my-0" id="dataTable">
                            <thead>
                                <tr>
                                    <th style="width: 500px;">Name</th>
                                    <th style="width: 170px;">Birth Date</th>
                                    <th style="width: 150px;">Course</th>
                                    <th style="width: 170px;">Message</th>
                                    <th style="width: 170px;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $team_invites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team_invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width: 264.828px;"><?php echo e($team_invite->user->firstname); ?> <?php echo e($team_invite->user->lastname); ?></td>
                                    <td><?php echo e($team_invite->user->birthdate); ?></td>
                                    <td><?php echo e($team_invite->user->course); ?></td>
                                    <td><?php echo e($team_invite->invite_message); ?></td>
                                    <td><a href="">JOIN</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th style="width: 500px;">Name</th>
                                    <th style="width: 170px;">Birth Date</th>
                                    <th style="width: 150px;">Course</th>
                                    <th style="width: 170px;">Role/Position</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-md-6 align-self-center">
                            <p id="dataTable_info" class="dataTables_info" role="status" aria-live="polite" style="margin-bottom: 0px;color: rgb(78,115,223);">Team Representative: Marthen Christ C. Escario</p>
                            <p id="dataTable_info-2" class="dataTables_info" role="status" aria-live="polite" style="margin-bottom: 0px;color: rgb(78,115,223);">Game Category: Sports</p>
                            <p id="dataTable_info-1" class="dataTables_info" role="status" aria-live="polite" style="color: rgb(78,115,223);">Game Type: Basketball</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.normal.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/normal/team/team_invites.blade.php ENDPATH**/ ?>