<nav class="navbar navbar-light navbar-expand-md sticky-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand" href="/">
      <img src="<?php echo e(asset('images/matchapp-icon.png')); ?>" style="height: 28px;width: 28px;">&nbsp;MatchAPP</a>
      <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navbarResponsive" type="button" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation" value="Menu">
        <i class="fa fa-bars"></i>
      </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item nav-link">
                    <a class="nav-link active" href="#MatchApp">Sign in</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH E:\dozaweb\apps\web\MatchApp-dev-MC\resources\views/templates/landing/nav_landing.blade.php ENDPATH**/ ?>