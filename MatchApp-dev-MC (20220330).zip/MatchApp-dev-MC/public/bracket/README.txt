Tournament PHP Script 1.0.0

Installation guide

1. Download and extract source-code.1.0.zip file.
2. Copy files from app folder (source-code.1.0/app/*) to your project.
3. Include class or classes to your project 'Visualizer.php' and 'Builder.php'
4. To start using generator you need call '$brackets = new Builder($names, $type);' Where $names is an array with team names and $type is a type of generator '0' is Random, '1' is Seeded, '2' is Reverse Seed  
5. To use on available Tournament you need call '$brackets = new Visualizer($teams_d, $settings)''; where $teams_d is an array with tournament data and $setting is an setting array read more please  <a href="https://bracketly.cloudcoding.me/?data=fifa2014&type=football">here</a>
6. Enjoy.

Visit for more information and updates: https://bracketly.cloudcoding.me/