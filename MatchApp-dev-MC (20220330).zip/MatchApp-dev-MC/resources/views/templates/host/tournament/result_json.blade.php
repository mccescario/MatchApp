<?php
echo $results;
?>