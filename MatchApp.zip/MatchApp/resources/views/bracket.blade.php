<link href="/bracket/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/bracket/assets/css/bracketlyStyle.css" rel="stylesheet">

<div class="row">
    {!! $bracket !!}
</div>
