<?php $__env->startPush('head'); ?>
<meta name="robots" content="noindex" />
<link href="<?php echo e(asset('/vendor/orchid/favicon.svg')); ?>" sizes="any" type="image/svg+xml" id="favicon" rel="icon">

<!-- For Safari on iOS -->
<meta name="theme-color" content="#21252a">
<?php $__env->stopPush(); ?>

<div class="h2 fw-light d-flex align-items-center">
    
    <img src="/logo.png" height="35" alt="Logo">
    <p class="ms-3 my-0 d-none d-sm-block">
        Match
        <small class="align-top opacity">APP</small>
    </p>
</div>
<?php /**PATH C:\Users\Jose Marie Dimapilis\Development\matchapp-orchid\resources\views/brand/header.blade.php ENDPATH**/ ?>