<?php if(auth()->guard()->guest()): ?>

<?php endif; ?>
<?php /**PATH /home/dfwtctbsltva/public_html/vendor/orchid/platform/resources/views/footer.blade.php ENDPATH**/ ?>