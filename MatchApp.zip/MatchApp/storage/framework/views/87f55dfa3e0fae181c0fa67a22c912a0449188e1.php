<div class="row">
    <div class="col-7 border-right mx-auto">
        <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 mb-2 mt-2">
            <div class="card mx-auto" style="width: 560px;">
                <div class="card-img-top">
                    <?php echo $match->stream_link; ?>

                </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($match->tournament->name); ?>: <?php echo e($match->team_one->name); ?> VS <?php echo e($match->team_two->name); ?></h5>
                    <p class="card-text">Match <?php echo e($match->order); ?>

                        <?php switch($match->level):
                        case (4): ?>
                        <span class="text-secondary"> Qualifications </span>
                        <?php break; ?>
                        <?php case (3): ?>
                        <span class="text-primary">Quarter-Finals</span>
                        <?php break; ?>
                        <?php case (2): ?>
                        <span class="text-info">Semi-Finals</span>
                        <?php break; ?>
                        <?php case (1): ?>
                        <span class="text-success">Finals</span>
                        <?php break; ?>
                        <?php endswitch; ?>
                    </p>

                    <p class="card-text">Score: <?php echo e($match->team_1_score); ?> - <?php echo e($match->team_2_score); ?></p>
                    
                    <a href="<?php echo e(route('tournaments.tournaments.view', $match->tournament->id)); ?>"
                        class="btn btn-primary">View <?php echo e($match->tournament->name); ?></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\Jose Marie Dimapilis\Development\matchapp-orchid\resources\views/matches.blade.php ENDPATH**/ ?>