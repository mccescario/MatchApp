<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH /home/dfwtctbsltva/public_html/vendor/orchid/platform/resources/views/partials/notification-wrap.blade.php ENDPATH**/ ?>