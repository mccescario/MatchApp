<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH C:\xampp\htdocs\matchapp-orchid\vendor\orchid\platform\resources\views/partials/notification-wrap.blade.php ENDPATH**/ ?>