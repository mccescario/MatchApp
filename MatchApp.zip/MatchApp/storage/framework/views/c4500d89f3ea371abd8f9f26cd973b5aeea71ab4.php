<link href="/bracket/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/bracket/assets/css/bracketlyStyle.css" rel="stylesheet">

<div class="row">
    <?php echo $bracket; ?>

</div>
<?php /**PATH C:\Users\Jose Marie Dimapilis\Development\matchapp-orchid\resources\views/bracket.blade.php ENDPATH**/ ?>