<link href="/bracket/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="/bracket/assets/css/bracketlyStyle.css" rel="stylesheet">

<div class="row">
    <?php echo $bracket; ?>

</div>
<?php /**PATH /home/dfwtctbsltva/public_html/resources/views/bracket.blade.php ENDPATH**/ ?>