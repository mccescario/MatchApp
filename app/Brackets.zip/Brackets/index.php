namespace App\Classes;

<?php
   error_reporting(0);
   ini_set('display_errors', 0);
   include('app/Visualizer.php');
   include('conn.php');
   include('app/Builder.php');
   $db_host     = "localhost";
   $db_username = "root";
   $db_password = "";
   $session_id = Session::getId(); //get nyo session ID in laravel tapos ilagay dito

   //connect to mysqli database (Host/Username/Password)
   $connection = mysqli_connect($db_host, $db_username, $db_password) or die("Error " . mysqli_error());

   //select MySQLi dabatase table
    $db = mysqli_select_db($connection, "tioszfko_matchapp") or die("Error " . mysqli_error());
//icacall nyo ung session ng host dito para mafetch nya ung mga users na kasali sa tournament nya:
  $sql = mysqli_query($connection, "SELECT * FROM teams where user_id = '$_SESSION'");

  while($row = mysqli_fetch_array($sql)) {
  $names[] = $row['name'];
}
   $default_teams = $names;
   if(!$_POST) {
    $_POST['teams'] = $default_teams;
    $_POST['typeof'] = 0;
   }
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Tournament Brackets Visualizer and Generator</title>
      <link href="./assets/css/bootstrap.min.css" rel="stylesheet">
      <link href="./assets/css/bracketlyStyle.css" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Saira+Semi+Condensed:100,200,300,400,500,600&display=swap" rel="stylesheet">
      <script src="./documentation/assets/highlight.pack.js"></script>
      <link href="./documentation/assets/github.css" rel="stylesheet">
      <script>hljs.initHighlightingOnLoad();</script>
   </head>
   <body>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
         <a class="navbar-brand" href="resources\views\templates\host\dashboard.blade.php"></a>
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
               <li class="nav-item">
                  <a class="nav-link" href="?data=tournament&type=generator">Tournament Bracket Generator</a>
               </li>
            </ul>
         </div>
      </nav>
      <div class="d-grid">
      <div class="grid-l">
      <form method="post" id="team-list-generator">
      <h4>Generate tournament</h4>
      <p>Just add teams with "Add team" button type name of the team, select generat type then just click to "Generate bracket" button and you see updated data in right of the screen.</p>
      <div class="title">Added team(s) list</div>
      <div class="list" sortable-list="sortable-list">
          <?php if(!empty($_POST['teams'])):?>
          <?php foreach( $_POST['teams'] as $sKey => $iQty ):?>
            <div class="list__item" sortable-item="sortable-item">
            <div class="list__item-content">
            <button type="button" class="remove"></button><input autocomplete="off" class="list__item-input" name="teams[<?php echo $sKey; ?>]" id="<?php echo $sKey; ?>" type="text" placeholder="Team name" value="<?php echo $iQty ?>">
            </div>
            <div class="list__item-handle" sortable-handle="sortable-handle"></div>
            </div>
          <?php endforeach; ?>
          <?php endif; ?>
      </div>
      <div class="control-group">
        <label class="control control--radio">Random
            <input value="0" <?php echo isset($_POST['typeof']) && $_POST['typeof'] == 0 ? ' checked' : '' ?> type="radio" name="typeof" checked="checked"/>
            <div class="control__indicator"></div>
        </label>
        <label class="control control--radio">Seeded
            <input value="1" <?php echo isset($_POST['typeof']) && $_POST['typeof'] == 1 ? ' checked' : '' ?> type="radio" name="typeof"/>
            <div class="control__indicator"></div>
        </label>
        <label class="control control--radio">Reverse seeded
            <input value="2" <?php echo isset($_POST['typeof']) && $_POST['typeof'] == 2 ? ' checked' : '' ?> type="radio" name="typeof"/>
            <div class="control__indicator"></div>
        </label>
        </div>
      <div class="team-list-form-footer">
        <button type="button" id="add-team" class="btn btn-light">Add team</button>
        <button type="submit" class="btn btn-light">Generate bracket</button>
      </div>
      </form>
      </div>
      <div class="grid-r">
      <div class="app-container">
         <?php
            if(isset($_GET['type']) && $_GET['type'] == "e-sport"){
                $file = './assets/json/major2013.json';
                $json = file_get_contents($file);
                $obj = json_decode($json);
                $teams_d = array();
                $teams_h = array();
                $teams_a = array();

                foreach($obj->matches as $match){
                    $teams_h["name"] = $match->team1;
                    $teams_h["score"] = $match->score1;

                    $teams_a["name"] = $match->team2;
                    $teams_a["score"] = $match->score2;

                    $teams_d[] = $teams_h;
                    $teams_d[] = $teams_a;
                }
                //Setting array
                //1. Show All teams image
                //2. Bronze match availabel and show it or dont show it true or false
                //3. Bronze match availabel in list but we need correction true or false
                $settings = array('image'=>false, 'bronze'=>false, 'nobronze' => false);
                $brackets = new Visualizer($teams_d, $settings);
                echo $brackets->RenderFromData();  

            } else if(isset($_GET['type']) && $_GET['type'] == "generator") {
                if(!empty($_POST['teams'])){
                    $names = array();
                    foreach( $_POST['teams'] as $sKey => $iQty ) {
                        if(!empty($iQty)){
                            array_push($names, $iQty);
                        }
                    }
                    $brackets = new Builder($names, $_POST['typeof']);
                    echo $brackets->RenderBrackets();
                } else {
                    $brackets = new Builder($default_teams, $_POST['typeof']);
                    echo $brackets->RenderBrackets();
                }
            } else {
                $file = 'https://raw.githubusercontent.com/openfootball/world-cup.json/master/2014/worldcup.json';
                if(isset($_GET['data']) && $_GET['data'] =='fifa2014'){
                    $file = 'https://raw.githubusercontent.com/openfootball/world-cup.json/master/2014/worldcup.json';
                } else if(isset($_GET['data']) && $_GET['data'] =='fifa2018'){
                    $file = 'https://raw.githubusercontent.com/openfootball/world-cup.json/master/2018/worldcup.json';
                }
                
                $json = file_get_contents($file);
                $obj = json_decode($json);
                $teams_d = array();
                $teams_h = array();
                $teams_a = array();
                
                foreach($obj->rounds as $matchdays){
                    foreach($matchdays->matches as $match){
                        if(isset($match->knockout)){
                            if($match->knockout == true){
                                $teams_h["name"] = $match->team1->name;
                                $teams_h["score"] = $match->score1;
                                $teams_h["et_score"] = $match->score1et;
                                $teams_h["pt_score"] = $match->score1p;
                
                                $teams_a["name"] = $match->team2->name;
                                $teams_a["score"] = $match->score2;
                                $teams_a["et_score"] = $match->score2et;
                                $teams_a["pt_score"] = $match->score2p;
                
                                $teams_d[] = $teams_h;
                                $teams_d[] = $teams_a;
                            }
                        }
                    }
                }

                if(isset($_GET['data']) && $_GET['data'] =='fifa2018'){
                //Setting array
                //1. Show All teams image
                //2. Bronze match available and we dont want to show it
                //3. Bronze match available in list but we need correct array
                $settings = array('image'=>false, 'bronze'=>false, 'nobronze' =>true);
                } else {
                                    //Setting array
                //1. Show All teams image
                //2. Bronze match available and we want to show it
                //3. Bronze match available in list but we need correct array
                $settings = array('image'=>true, 'bronze'=>true, 'nobronze' =>true);
                }

                $brackets = new Visualizer($teams_d, $settings);
                echo $brackets->RenderFromData();   
            }
            ?>
      </div>
      </div>
      </div>
      <script src="./assets/js/jquery-3.4.1.min.js"></script>
      <script src="./assets/js/bootstrap.min.js"></script>
      <script src="./assets/js/jquery-ui.min.js"></script>
      <script src="./assets/js/jquery-multisortable.min.js"></script>
      <script src="./assets/js/bracketly.js"></script>
   </body>
</html>