<?php
$db_host     = "localhost";
   $db_username = "root";
   $db_password = "";
   $session_id = Session::getId(); //get nyo session ID in laravel tapos ilagay dito

  $con=mysqli_connect("localhost",$db_username,$db_password,"tioszfko_matchapp");

  // Check connection
  if (mysqli_connect_errno())
  {
   echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//icacall nyo ung session ng host dito para mafetch nya ung mga users na kasali sa tournament nya:
  $query = mysqli_query($connection, "SELECT * FROM teams where user_id = '$_SESSION'");

  $result = mysqli_query($con,$query);

  $rows = array();
  while($r = mysqli_fetch_array($result)) {
    $rows[] = $r;
  }
  echo json_encode($rows);

  mysqli_close($con);
?>